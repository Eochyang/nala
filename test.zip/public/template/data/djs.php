<?php
    $start = $_GET['start'];
    $end = $_GET['end'];
    echo $end - $start;
?>