import "../libs/jquery-2.2.4.js";
import "../libs/jquery.banner.1.0.1.js";
import "../libs/jquery.cookie.js";
import { Goods } from "./list-goods.js";
import { Mainlogin } from "./main-login.js";
import { Menu } from "./menu.js";
import { Nav } from "./index-nav.js";


new Goods();
new Mainlogin();
new Menu();
new Nav();