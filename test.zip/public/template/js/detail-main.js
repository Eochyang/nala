import "../libs/jquery-2.2.4.js";
import "../libs/jquery.cookie.js";
import { Detail } from "./detail-data.js";
import { Goods } from "./detail-car.js";
import { Mainlogin } from "./main-login.js";
import { Fdj } from "./detail-fdj.js";
import { Menu } from "./menu.js";
import { Nav } from "./index-nav.js";

new Detail();
new Goods();
new Mainlogin()
new Fdj();
new Menu();
new Nav();